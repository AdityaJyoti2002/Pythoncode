# Education-website
# django create new web application
# this is education site 
