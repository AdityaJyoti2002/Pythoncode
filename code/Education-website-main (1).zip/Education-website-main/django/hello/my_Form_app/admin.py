from django.contrib import admin
from my_Form_app.models import Log 

# Register your models here.
admin.site.register(Log)
